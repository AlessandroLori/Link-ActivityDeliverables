package seleniumtestapipicagiada;

import org.junit.jupiter.api.Test;

import java.util.Objects;


public class Start {
    @Test
    public void main() {
        MainPage mainPage = new MainPage();
        String winxname = mainPage.getWinxName();
        assert (Objects.equals(winxname, "Tecna"));
    }
}