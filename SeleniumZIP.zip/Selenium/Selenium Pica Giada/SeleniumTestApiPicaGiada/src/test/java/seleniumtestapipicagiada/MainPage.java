package seleniumtestapipicagiada;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;




public class MainPage {

    public String getWinxName(){
        System.setProperty("webdriver.chrome.driver", "src/test/java/seleniumtestapipicagiada/chromedriver.exe");
        WebDriver chromeDriver = new ChromeDriver();
        chromeDriver.get("https://www.google.com/");
        chromeDriver.findElement(By.xpath("//*[@id=\"W0wltc\"]/div")).click();
        chromeDriver.findElement(By.xpath("//*[@id=\"APjFqb\"]")).click();
        WebElement textInput = chromeDriver.findElement(By.xpath("//*[@id=\"APjFqb\"]")) ;
        textInput.sendKeys("Personaggi Winx");
        WebElement search= chromeDriver.findElement(By.xpath("/html/body/div[1]/div[3]/form/div[1]/div[1]/div[2]/div[2]/div[5]/center/input[1]"));
        search.click();
        WebElement winxName=chromeDriver.findElement(By.xpath("/html/body/div[6]/div/div[11]/div[3]/div[1]/div[2]/div/div/div/div/div/div/div/div/div[2]/div/div/div/div/div[3]/div[1]/div/div/div[2]/div/wp-grid-view/div/div[1]/div[6]/div/a/wp-grid-tile/div[2]/div[1]"));
        String nome= winxName.getText();
        System.out.println(nome);
        chromeDriver.close();
        return nome;
    }
}
