package com.example.seleniumtestapilorialessandro;

import org.junit.jupiter.api.Test;
import java.util.Objects;

public class TestSeleniumTest {

    /*
        Responsabile testing: Alessandro Lori
        Matricola: 0280155
    */

    @Test
    public void testGetName() {
        SeleniumTest seleniumTest = new SeleniumTest() ;

        String nome = seleniumTest.getName() ;

        assert(Objects.equals(nome, "Sergio Mattarella")) ;
    }
}
