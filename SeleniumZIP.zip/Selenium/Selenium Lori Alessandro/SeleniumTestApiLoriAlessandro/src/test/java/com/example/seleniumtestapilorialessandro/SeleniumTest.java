package com.example.seleniumtestapilorialessandro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class SeleniumTest {

    /*
        Responsabile testing: Alessandro Lori
        Matricola: 0280155
    */

    public String getName() {
        System.setProperty("webdriver.chrome.driver", "src/test/java/com/example/seleniumtestapilorialessandro/chromedriver.exe") ;
        WebDriver chromeDriver = new ChromeDriver() ;
        chromeDriver.get("https://it.wikipedia.org/w/index.php?search=&title=Speciale:Ricerca&go=Vai");

        chromeDriver.findElement(By.xpath("//*[@id=\"ooui-php-1\"]")).click();
        WebElement inputText=chromeDriver.findElement(By.xpath("//*[@id=\"ooui-php-1\"]"));
        inputText.sendKeys("Presidente della Repubblica Italiana");
        chromeDriver.findElement(By.xpath("//*[@id=\"mw-search-top-table\"]/div/div/div/span/span/button")).click();
        chromeDriver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div[4]/div[4]/ul/li[2]/table/tbody/tr/td[2]/div[1]/a")).click();
        //chromeDriver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div[1]/table[1]/tbody/tr[7]/td/a"));
        WebElement nameElement= chromeDriver.findElement(By.xpath("//*[@id=\"mw-content-text\"]/div[1]/table[1]/tbody/tr[7]/td/a"));
        String name= nameElement.getText();
        System.out.println(name);
        return name;
    }
}
